﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*BUGS
/When one of the models collides with something, the other one and the camera will continue moving
Consider not using rigidbodies and instead implementing a basic physics system
*/
public class Player : MonoBehaviour
{
    [SerializeField]
    Camera followCam;
    [SerializeField]
    Model a;
    [SerializeField]
    Model b;
    bool transformed = false;
    Model currentModel
    {
        get
        {
            return transformed ? b : a;
        }
    }
    Model previousModel
    {
        get
        {
            return transformed ? a : b;
        }
    }

    // Use this for initialization
    void Start()
    {
        currentModel.UpdateCamera(followCam);
    }

    // Update is called once per frame
    void Update()
    {
        //If the player presses the transform button/key
        if(Input.GetKeyDown(KeyCode.T) /* && the other model's collider doesn't intersect with anything or something along those lines*/)
        {
            previousModel.transform.position = currentModel.transform.position;
            currentModel.gameObject.SetActive(false);
            previousModel.gameObject.SetActive(true);
            //update whether the player is transformed
            transformed = !transformed;
        }
        //followCam.transform.position += (transform.position - prevPos);
        currentModel.UpdateCamera(followCam);
    }
}
